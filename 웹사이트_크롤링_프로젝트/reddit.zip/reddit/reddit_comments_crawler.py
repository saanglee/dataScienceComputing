import csv
from bs4 import BeautifulSoup
import requests
import datetime

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from webdriver_manager.chrome import ChromeDriverManager

REDDIT_URL = 'https://www.reddit.com/r/WatchPeopleDieInside/comments/10dbt92/when_your_legs_give_up/'

def comment_crawler(URL):
    start_time = datetime.datetime.now()

    driver = webdriver.Chrome(service= Service(ChromeDriverManager().install()))
    driver.get(URL)

    comment_tree_div = driver.find_element(By.ID, 'comment-tree-content-anchor-10dbt92')
    comment_elements = comment_tree_div.find_elements(By.TAG_NAME, 'shreddit-comment')
    print(len(comment_elements))

    for comment_element in comment_elements:
        Find the <div> with the specified class containing the comment content
        comment_content_div = comment_element.find_element(By.CSS_SELECTOR, '.md.text-14.rounded-[8px].pb-2xs')
        comment_content_div = comment_element.find_element(By.CLASS_NAME, 'md.text-14.rounded-[8px].pb-2xs')
        
        p_tags = comment_content_div.find_elements(By.TAG_NAME, 'p')
        
        for p_tag in p_tags:
            print("Text of <p> tag:", p_tag.text)





comment_crawler(REDDIT_URL)

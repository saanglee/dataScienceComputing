"""
• 주 요 기 능
    1. 학 생 이 고 른 웹 페 이 지 를 입 력 받 을 수 있 어 야 함 .
    2. 입 력 받 은 웹 페 이 지 를 본 인 나 름 대 로 정 한 고 유 한 정 의 를 통 해 분 류 하 고 이 를
        C S V 파 일 로 저 장 하 여 e x p o r t 할 수 있 어 야 함 .
    3. 출 력 C S V 파 일 의 이 름 은 현 재 날 짜 과 시 간 이 포 함 된 C S V 파 일 이 어 야 함
    예 : 현 재 시 간 이 2 0 x x 년 5 월 1 9 일 오 후 3 시 2 0 분 일 경 우 - 2 0 X X 0 5 1 9 1 5 2 0 . c s v
    4 . 완 료 후 에 는 크 롤 링 결 과 와 소 요 시 간 을 안 내 해 주 어 야 함 .
• 주 의 사 항
    1 . 대 상 웹 페 이 지 의 경 우 , 온 라 인 게 시
    2 . 해 당 크 롤 러 의 경 우 , 각 l i n e 이 어 떠 한 역 할 과 동 작 을 하 는 지 주 석 을 쓸 것 .

 ID/포스팅 내용/upvotes/ comments
 fieldnames = ['id', 'title', 'upvotes', 'content', 'comments']
"""

import csv
from bs4 import BeautifulSoup
import requests
import datetime

REDDIT_URL = 'https://www.reddit.com/posts/2023/global/?rdt=51977'


def save_to_csv(data):
    fieldnames = ['id', 'title', 'upvotes', 'content', 'comments']
    
    current = datetime.datetime.now().strftime('%Y%m%d%H%M')  

    with open(f'{current}.csv', mode='w', newline='', encoding='utf-8') as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(data)



def crawler(URL):
    start_time = datetime.datetime.now()
    print('Start time: ', start_time)

    response = requests.get(URL)
    html = BeautifulSoup(response.text, 'html.parser')

    POST_CLASS = 'py-md px-md xs:px-0'
    posts = html.find_all('div', class_=POST_CLASS)
    posts_for_csv = []
    for post in posts[:2]:
        id = post.find('div', class_='ml-xs truncate').get_text(strip=True)
        title = post.find('h3', class_='i18n-list-item-post-title text-14 line-clamp-2 m-0 font-semibold overflow-hidden group-hover:underline').get_text(strip=True)
        upvotes_div = post.find('div', class_='text-neutral-content-weak text-12')
        upvotes = upvotes_div.find('faceplate-number')['number']
        
        a_tags = post.find_all('a')
        if len(a_tags) > 1:
            post_url = a_tags[2]['href']
            response = requests.get(f'https://www.reddit.com{post_url}')
            post_html = BeautifulSoup(response.text, 'html.parser')
            main_tag = post_html.find('main')
            content = main_tag.find('div', class_='pointer-events-none absolute inset-0 border-sm border-solid border-neutral-border-weak pointer-events-none absolute inset-0 z-[3] border-sm border-solid border-neutral-border-weak xs:rounded-[16px] border-x-0 xs:border-x-sm]')
            video_link = content.find('video')
            print('video_link:', video_link)

            if post_html.find('video'):
                content = post_html.find('video')['src']
            elif post_html.find('img'):
                content = post_html.find('img')['src']
            elif post_html.find('div', class_='text-neutral-content'):
                content = post_html.find('div', class_='text-neutral-content').get_text(strip=True)
            else:
                content = ''
        
        comments_text = ""
        for comment in post_html.find_all('p', class_='shreddit-comment'):
            comments_text += comment.get_text(strip=True) + " "

        post = {
            'id': id,
            'title': title,
            'upvotes': upvotes,
            'content': content,
            'comments': comments_text
        }
        posts_for_csv.append(post)
    
    save_to_csv(posts_for_csv)

    end_time = datetime.datetime.now()
    elapsed_time = end_time - start_time
    print(f"Crawling and saving completed successfully in {elapsed_time.total_seconds()} seconds.")



try:
    crawler(REDDIT_URL)
    print("Success: Crawling and saving completed.")
except Exception as e:
    print("Error: ", e)
